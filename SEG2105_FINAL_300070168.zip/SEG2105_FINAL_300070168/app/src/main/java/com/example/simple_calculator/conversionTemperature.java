package com.example.simple_calculator;

//Class for temperature conversion calculation
public class conversionTemperature {

    public double convert(String beforeConvert, String afterConvert, double input) {
        double userInput = input;
        double result = 0.0d;
        double tempNum;

        String beforeConvertSele = beforeConvert.toLowerCase();
        String afterConvertSele = afterConvert.toLowerCase();

        switch(beforeConvertSele)
        {
            case "celsius":
            {
                switch(afterConvertSele)
                {
                    case "celsius":
                        result = userInput;
                        break;
                    case "fahrenheit":
                        result = (userInput*(9.0/5.0)) + 32d;
                        break;
                    case "kelvin":
                        result = userInput + 273.15d;
                        break;
                }
                break;
            }
            case "fahrenheit":
            {
                switch(afterConvertSele)
                {
                    case "celsius":
                        tempNum = (-userInput - 32d);
                        result = tempNum * (5.0/9.0);
                        break;
                    case "fahrenheit":
                        result = userInput;
                        break;
                    case "kelvin":
                        result = ((userInput - 32d)*(5.0/9.0)) + 273.15d;
                        break;
                }
                break;
            }
            case "kelvin":
            {
                switch(afterConvertSele)
                {
                    case "celsius":
                        result = userInput - 273.15d;
                        break;
                    case "fahrenheit":
                        result = ((userInput - 273.15d) *(9.0/5.0)) + 32d;
                        break;
                    case "kelvin":
                        result = userInput;
                        break;
                }
                break;
            }
        }

        return result;
    }
}
