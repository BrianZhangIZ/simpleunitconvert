package com.example.simple_calculator;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

//Main class for switching between activities
public class panelSwitcher extends AppCompatActivity {
    Button buttonChange, buttonChange2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_panel);

        //Create buttons for each activity
        buttonChange = (Button) findViewById(R.id.buttonChange);
        buttonChange2 = (Button) findViewById(R.id.buttonChange2);

        //Assigning specific classes to the intended buttons
        buttonChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(panelSwitcher.this, MainActivity.class);
                startActivity(i);
            }

        });
        buttonChange2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(panelSwitcher.this, MainActivityTemp.class);
                startActivity(i);
            }

        });
    }
}
